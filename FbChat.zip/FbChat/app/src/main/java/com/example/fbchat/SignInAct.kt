package com.example.fbchat

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import com.example.fbchat.databinding.ActivitySignInBinding
import com.google.android.gms.auth.api.credentials.IdToken
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

class SignInAct : AppCompatActivity() {
    lateinit var launcher: ActivityResultLauncher<Intent>
    lateinit var auth: FirebaseAuth
    lateinit var binding: ActivitySignInBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignInBinding.inflate(layoutInflater)
        setContentView(binding.root)
        auth = Firebase.auth
        launcher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()){ //иницеизируем лаунчер
            val task = GoogleSignIn.getSignedInAccountFromIntent(it.data) // Расспаковка токена и получение из него информации
            try {
                val account = task.getResult(ApiException::class.java)
                if (account !=  null) {
                    firebaseAuthWithGoogle(account.idToken!!)
                }
            } catch (e: ApiException){
                Log.d("MyLog", "Api exception")
            }
        }
        binding.bSignIn.setOnClickListener {
            signInWithGoogle()
        }
        checkAuthState()
    }

    private fun getClient(): GoogleSignInClient{  //настройка запросса для вывода окна с вобором аккаунта
        val gso = GoogleSignInOptions
            .Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(getString(R.string.default_web_client_id))
            .requestEmail()
            .build()
        return GoogleSignIn.getClient(this, gso) //после регестрации (входа в аккаунт) получчим токин
    }

    private  fun signInWithGoogle(){
        val signInClient = getClient()
        launcher.launch(signInClient.signInIntent) // С помощью лаунчера запускаем наш signInIntent
    }

    private fun firebaseAuthWithGoogle(idToken: String){   //подключение аккаунта к firebase
        val credential = GoogleAuthProvider.getCredential(idToken, null)
        auth.signInWithCredential(credential).addOnCompleteListener {
           if(it.isSuccessful) {
               Log.d("MyLog", "Google signIn done")  // в случии успешного подключения
               checkAuthState()
           } else {
               Log.d("MyLog", "Google signIn error")  // в случии не успешного подключения
           }
        }
    }

    private fun checkAuthState () {  // После успешной регестрации пересылаем пользователся на startActivity
        if(auth.currentUser != null) {
            val i = Intent(this, MainActivity::class.java)
            startActivity(i)
        }
    }

}