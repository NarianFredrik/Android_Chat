package com.example.fbchat

data class User(
    val name: String? = null,
    val message: String? = null
)
